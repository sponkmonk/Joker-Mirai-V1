#pragma once

#define HTTP_SERVER "185.216.71.192"
#define HTTP_PORT 80

#define TFTP_SERVER "185.216.71.192"
